# JSYS 麦克风阵列 ROS2 功能包

基于 ROS2 的麦克风阵列串口通信与音频处理系统。

## 功能包说明

### 1. mic_interfaces
**消息和服务接口定义包**

定义了系统中使用的所有自定义消息和服务：

**消息类型**：
- `AudioData.msg` - 音频数据消息（原始音频、降噪音频）

**服务类型**：
- `GetVersion.srv` - 获取设备版本信息
- `ControlAudio.srv` - 控制音频流开关
- `ManualWakeup.srv` - 手动触发唤醒
- `SetWakeupKeyword.srv` - 设置唤醒关键词和阈值

### 2. mic_server
**麦克风阵列串口通信服务**

负责与麦克风阵列设备的串口通信，包括握手、命令发送、音频数据接收和唤醒事件处理。

**功能**：
- 双串口架构：
  - 交互串口（`/dev/ttyUSB0`）：握手、命令、唤醒消息
  - 音频串口（`/dev/ttyACM0`）：原始音频数据流
- 自动握手连接
- 发布原始音频数据到 `/mic/original_audio`
- 发布唤醒事件到 `/mic/wakeup_event`
- 提供设备控制服务

**配置文件**：`config/mic_params.yaml`
```yaml
control_port: "/dev/ttyUSB0"  # 交互串口
audio_port: "/dev/ttyACM0"    # 音频串口
baud_rate: 115200
```

### 3. mic_record
**USB 麦克风录制与降噪**

使用 ALSA 录制 USB 麦克风音频并进行降噪处理。

**功能**：
- 录制 USB 麦克风音频（ALSA）
- 音频降噪处理
- 发布降噪后的音频到 `/mic/denoised_audio`

**配置**：在 launch 文件中配置 USB 麦克风设备名称

### 4. mic_server_virtual
**单串口麦克风通信服务器（虚拟版本）**

`mic_server_virtual` 是 `mic_server` 的单串口版本，将原有的双串口架构改为单串口架构。

**架构差异**：

| 特性 | mic_server | mic_server_virtual |
|------|------------|-------------------|
| 交互串口 | /dev/ttyUSB0 | /dev/ttyACM0 |
| 音频串口 | /dev/ttyACM0 | /dev/ttyACM0（共享） |
| 串口数量 | 2 | 1 |

**配置参数**：
```yaml
/**:
  ros__parameters:
    serial_port: "/dev/ttyACM0"  # 串口设备（交互 + 音频）
    baud_rate: 115200            # 波特率
```

**启动**：
```bash
ros2 launch mic_server_virtual mic_server.launch.py
```

**协议**：与 `mic_server` 完全一致，所有消息通过单个串口收发，根据消息类型分发。

## 启动系统

### 启动麦克风服务器
```bash
# 编译
colcon build

# 加载环境
source install/setup.bash

# 启动 mic_server
ros2 launch mic_server mic_server.launch.py
```

### 启动 USB 麦克风录制（可选）
```bash
ros2 launch mic_record mic_record.launch.py
```

## 服务调用示例

### 1. 获取设备版本
```bash
ros2 service call /mic/get_version mic_interfaces/srv/GetVersion "{}"
```

**响应示例**：
```
success: True
version: '{"version":"1.0.0","build":"20240101"}'
message: '获取版本成功'
```

### 2. 控制音频流

**启动音频发布**：
```bash
ros2 service call /mic/control_audio mic_interfaces/srv/ControlAudio "{enable: true}"
```

**停止音频发布**：
```bash
ros2 service call /mic/control_audio mic_interfaces/srv/ControlAudio "{enable: false}"
```

### 3. 手动唤醒
```bash
# beam 参数指定波束方向（0-7），通常使用 0
ros2 service call /mic/manual_wakeup mic_interfaces/srv/ManualWakeup "{beam: 0}"
```

**响应示例**：
```
success: True
message: '手动唤醒成功'
```

### 4. 设置唤醒关键词

**只设置关键词（阈值默认 900）**：
```bash
ros2 service call /mic/set_wakeup_keyword mic_interfaces/srv/SetWakeupKeyword "{keyword: '你好小智'}"
```

**设置关键词和阈值**：
```bash
ros2 service call /mic/set_wakeup_keyword mic_interfaces/srv/SetWakeupKeyword "{keyword: '你好小智', threshold: 800}"
```

**注意**：
- 唤醒词不能为空，否则返回错误
- 阈值为 0 时自动使用默认值 900
- 阈值范围通常为 0-1000，值越高越严格

## 话题订阅示例

### 订阅原始音频
```bash
ros2 topic echo /mic/original_audio
```

### 订阅降噪音频
```bash
ros2 topic echo /mic/denoised_audio
```

### 订阅唤醒事件
```bash
ros2 topic echo /mic/wakeup_event
```

**唤醒事件消息格式**（JSON 字符串）：
```json
{
  "aiui_event": "wakeup",
  "keyword": "你好小智",
  "beam": 0,
  "confidence": 950
}
```

## 查看话题和服务

### 查看所有话题
```bash
ros2 topic list
```

### 查看所有服务
```bash
ros2 service list
```

### 查看话题信息
```bash
ros2 topic info /mic/original_audio
ros2 topic hz /mic/original_audio  # 查看发布频率
```

### 查看服务类型
```bash
ros2 service type /mic/get_version
```

## 协议说明

### 串口消息格式
```
同步头 (0xA5) + 用户 ID(0x01) + 消息类型 (1 字节) + 消息长度 (2 字节，小端) +
消息 ID(2 字节) + 消息数据 (N 字节) + 校验码 (1 字节)
```

### 消息类型
- `0x01` - 握手请求
- `0x04` - 唤醒消息
- `0x05` - 手动命令（版本查询、手动唤醒、设置关键词等）
- `0x06` - 音频数据
- `0xFF` - 握手响应

### 命令格式（JSON）

**获取版本**：
```json
{"type":"version"}
```

**手动唤醒**：
```json
{"type":"manual_wakeup","content":{"beam":0}}
```

**设置唤醒关键词**：
```json
{"type":"wakeup_keywords","content":{"keyword":"你好小智","threshold":"900"}}
```

## 故障排查

### 串口权限问题
```bash
sudo chmod 666 /dev/ttyUSB0
sudo chmod 666 /dev/ttyACM0
```

### 查看节点日志
```bash
ros2 node list
ros2 node info /mic_server
```

### 检查串口设备
```bash
ls -l /dev/ttyUSB* /dev/ttyACM*
```

### 测试串口通信
```bash
# 查看串口数据
cat /dev/ttyUSB0

# 或使用 minicom
sudo minicom -D /dev/ttyUSB0 -b 115200
```

## 开发说明

### 编译单个功能包
```bash
colcon build --packages-select mic_interfaces
colcon build --packages-select mic_server
colcon build --packages-select mic_record
colcon build --packages-select mic_server_virtual
```

### 清理编译
```bash
rm -rf build install log
```

### 代码格式化
```bash
# C++ 代码使用 clang-format
find src -name "*.cpp" -o -name "*.hpp" | xargs clang-format -i
```

## 依赖项

- ROS2 Humble
- ALSA 库（用于 USB 麦克风录制）
- Linux 串口驱动（POSIX termios）

## 许可证

TODO: 添加许可证信息
