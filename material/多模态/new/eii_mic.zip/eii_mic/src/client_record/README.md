# Client Record

订阅音频话题并将数据保存到本地 PCM 文件的功能包。

## 功能

- 订阅两个音频话题（原始音频和降噪音频）
- 将音频数据保存为 PCM 文件
- 支持通过 YAML 配置文件自定义保存路径和话题名称
- 支持设置录音时长（可选）

## 依赖

- ROS 2 Humble
- mic_interfaces（自定义消息类型）

## 编译

```bash
cd ~/ros2_ws
colcon build --packages-select client_record
source install/setup.bash
```

## 使用方法

### 1. 使用默认配置启动

```bash
ros2 launch client_record client_record.launch.py
```

### 2. 使用自定义配置启动

```bash
ros2 launch client_record client_record.launch.py config_file:=/path/to/your/config.yaml
```

### 3. 直接运行节点

```bash
ros2 run client_record client_record_node --ros-args --params-file $(ros2 pkg prefix client_record)/share/client_record/config/record_params.yaml
```

## 配置参数

在 `config/record_params.yaml` 中只需配置保存目录：

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `save_directory` | 音频文件保存目录 | `/tmp/audio_recordings` |

**其他设置均已写死：**
- 话题名称：`/mic/original_audio` 和 `/mic/denoised_audio`
- 文件名格式：`audio_{topic}_{timestamp}.pcm`
- 录音模式：持续录音（直到手动停止）

## 输出文件

节点会生成两个 PCM 文件：

- `audio_original_YYYYMMDD_HHMMSS_mmm.pcm` - 原始音频数据
- `audio_denoised_YYYYMMDD_HHMMSS_mmm.pcm` - 降噪音频数据

文件名格式：`audio_{topic}_{timestamp}.pcm`

其中时间戳格式为：`YYYYMMDD_HHMMSS_mmm`（年月日_时分秒_毫秒）

## 播放 PCM 文件

使用 ffplay 播放录制的 PCM 文件：

```bash
# 播放原始音频（16kHz, 单声道，16 位小端）
ffplay -f s16le -ar 16000 -ac 1 audio_original_*.pcm

# 播放降噪音频
ffplay -f s16le -ar 16000 -ac 1 audio_denoised_*.pcm
```

## 注意事项

- 首次收到音频数据时才会创建文件
- 手动停止节点（Ctrl+C）时会关闭所有文件
- 确保保存目录存在且有写入权限
