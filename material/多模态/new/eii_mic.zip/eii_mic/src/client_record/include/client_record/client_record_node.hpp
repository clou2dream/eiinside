#ifndef CLIENT_RECORD__CLIENT_RECORD_NODE_HPP_
#define CLIENT_RECORD__CLIENT_RECORD_NODE_HPP_

#include <rclcpp/rclcpp.hpp>
#include <mic_interfaces/msg/audio_data.hpp>
#include <std_msgs/msg/string.hpp>

#include <string>
#include <fstream>
#include <chrono>
#include <filesystem>

namespace client_record
{

class ClientRecordNode : public rclcpp::Node
{
public:
  explicit ClientRecordNode(const rclcpp::NodeOptions & options = rclcpp::NodeOptions());
  ~ClientRecordNode();

private:
  // 回调函数
  void original_audio_callback(const mic_interfaces::msg::AudioData::SharedPtr msg);
  void denoised_audio_callback(const mic_interfaces::msg::AudioData::SharedPtr msg);
  
  // 订阅者
  rclcpp::Subscription<mic_interfaces::msg::AudioData>::SharedPtr original_audio_sub_;
  rclcpp::Subscription<mic_interfaces::msg::AudioData>::SharedPtr denoised_audio_sub_;

  // 状态
  bool is_recording_;
  
  std::string save_directory_;

  // 文件流
  FILE *original_audio_file_;
  FILE *denoised_audio_file_;

  std::string original_audio_filename_;
  std::string denoised_audio_filename_;
};

}  // namespace client_record

#endif  // CLIENT_RECORD__CLIENT_RECORD_NODE_HPP_
