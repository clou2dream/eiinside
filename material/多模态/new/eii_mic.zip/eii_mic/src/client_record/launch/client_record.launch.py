#!/usr/bin/env python3
"""
Client Record 启动文件
订阅音频话题并保存到本地 PCM 文件
"""

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    # 声明启动参数
    config_file_arg = DeclareLaunchArgument(
        'config_file',
        default_value=PathJoinSubstitution([
            FindPackageShare('client_record'),
            'config',
            'record_params.yaml'
        ]),
        description='配置文件路径'
    )
    
    config_file = LaunchConfiguration('config_file')
    
    # 创建节点
    client_record_node = Node(
        package='client_record',
        executable='client_record_node',
        name='client_record',
        output='screen',
        emulate_tty=True,
        parameters=[config_file],
    )
    
    return LaunchDescription([
        config_file_arg,
        client_record_node,
    ])
