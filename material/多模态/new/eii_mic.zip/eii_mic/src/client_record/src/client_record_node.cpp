#include "client_record/client_record_node.hpp"

#include <filesystem>
#include <iomanip>
#include <sstream>

namespace client_record
{

ClientRecordNode::ClientRecordNode(const rclcpp::NodeOptions &options)
    : Node("client_record", options),
      is_recording_(false)
{
    // 声明参数（只保留保存目录）
    this->declare_parameter<std::string>("save_directory", "/tmp/audio_recordings");

    // 获取参数
    save_directory_ = this->get_parameter("save_directory").as_string();

    // 创建保存目录
    try
    {
        std::filesystem::create_directories(save_directory_);
        RCLCPP_INFO(this->get_logger(), "创建保存目录：%s", save_directory_.c_str());
    }
    catch (const std::filesystem::filesystem_error &e)
    {
        RCLCPP_ERROR(this->get_logger(), "创建保存目录失败：%s", e.what());
        throw;
    }

    // 创建订阅者
    auto qos = rclcpp::QoS(10);

    original_audio_sub_ = this->create_subscription<mic_interfaces::msg::AudioData>("/mic/original_audio", qos, std::bind(&ClientRecordNode::original_audio_callback, this, std::placeholders::_1));

    denoised_audio_sub_ = this->create_subscription<mic_interfaces::msg::AudioData>("/mic/denoised_audio", qos, std::bind(&ClientRecordNode::denoised_audio_callback, this, std::placeholders::_1));

    RCLCPP_INFO(this->get_logger(), "已订阅话题：");
    RCLCPP_INFO(this->get_logger(), "  - 原始音频：/mic/original_audio");
    RCLCPP_INFO(this->get_logger(), "  - 降噪音频：/mic/denoised_audio");
    RCLCPP_INFO(this->get_logger(), "保存路径：%s", save_directory_.c_str());
    RCLCPP_INFO(this->get_logger(), "录音模式：持续录音（直到手动停止）");

    is_recording_ = true;

    original_audio_filename_ = save_directory_ + "/audio_original.pcm";
    denoised_audio_filename_ = save_directory_ + "/audio_denoised.pcm";
}

ClientRecordNode::~ClientRecordNode()
{
    if (original_audio_file_ != nullptr)
    {
        fclose(original_audio_file_);
    }
    if (denoised_audio_file_ != nullptr)
    {
        fclose(denoised_audio_file_);
    }
}

void ClientRecordNode::original_audio_callback(const mic_interfaces::msg::AudioData::SharedPtr msg)
{
    if (!is_recording_)
    {
        return;
    }
    if (original_audio_file_ == nullptr)
    {
        original_audio_file_ = fopen(original_audio_filename_.c_str(), "wb");
    }
    fwrite(msg->data.data(), 1, msg->data.size(), original_audio_file_);
    fflush(original_audio_file_);
}

void ClientRecordNode::denoised_audio_callback(const mic_interfaces::msg::AudioData::SharedPtr msg)
{
    if (!is_recording_)
    {
        return;
    }
    if (denoised_audio_file_ == nullptr)
    {
        denoised_audio_file_ = fopen(denoised_audio_filename_.c_str(), "wb");
    }
    fwrite(msg->data.data(), 1, msg->data.size(), denoised_audio_file_);
    fflush(denoised_audio_file_);
}


}    // namespace client_record

int main(int argc, char *argv[])
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<client_record::ClientRecordNode>(rclcpp::NodeOptions()));
    rclcpp::shutdown();
    return 0;
}
