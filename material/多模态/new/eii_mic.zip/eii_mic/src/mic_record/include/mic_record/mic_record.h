#ifndef _MIC_RECORD_H
#define _MIC_RECORD_H

#include <alsa/asoundlib.h>
#include <string.h>

#include <atomic>
#include <chrono>
#include <iostream>
#include <memory>
#include <thread>

#include "mic_interfaces/msg/audio_data.hpp"
#include "rclcpp/rclcpp.hpp"

class MicRecord : public rclcpp::Node {
 public:
  MicRecord(const std::string& node_name);
  ~MicRecord();

  /**
   * @brief 开始音频捕获
   * @return 成功返回0，失败返回错误码
   */
  int Start();

  /**
   * @brief 停止音频捕获
   * @return 成功返回0，失败返回错误码
   */
  int Stop();

 private:
  /**
   * @brief 音频捕获线程函数
   */
  void CaptureThread();

  /**
   * @brief 发布音频数据
   * @param audio_data 音频数据指针
   * @param len 音频数据长度（字节数）
   */
  void PublishAudio(const void* audio_data, int len);

 private:
  snd_pcm_t* pcm_handle_;         // ALSA PCM 句柄
  std::atomic<bool> is_running_;  // 运行状态标志
  std::thread capture_thread_;    // 音频捕获线程

  rclcpp::Publisher<mic_interfaces::msg::AudioData>::SharedPtr audio_pub_;  // 音频发布器

  // 音频参数
  const unsigned int SAMPLE_RATE = 16000;                 // 采样率
  const unsigned int CHANNELS = 1;                        // 声道数
  const unsigned int FRAME_SIZE = 640;                    // 帧大小
  const snd_pcm_format_t FORMAT = SND_PCM_FORMAT_S16_LE;  // 采样格式
};

#endif