#!/usr/bin/env python3
"""
Mic Record 启动文件
"""

from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    # 创建节点
    mic_record_node = Node(
        package='mic_record',
        executable='mic_record_node',
        name='mic_record',
        output='screen',
        emulate_tty=True,
    )

    return LaunchDescription([
        mic_record_node,
    ])
