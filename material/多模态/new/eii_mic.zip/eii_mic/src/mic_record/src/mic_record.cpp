#include "mic_record/mic_record.h"

MicRecord::MicRecord(const std::string& node_name) : Node(node_name), pcm_handle_(nullptr), is_running_(false) {
  // 创建音频发布器 - 发布降噪音频
  audio_pub_ = this->create_publisher<mic_interfaces::msg::AudioData>("/mic/denoised_audio", 10);

  RCLCPP_INFO(this->get_logger(), "MicRecord node initialized");
}

MicRecord::~MicRecord() { Stop(); }

int MicRecord::Start() {
  if (is_running_) {
    RCLCPP_WARN(this->get_logger(), "Audio capture is already running");
    return -1;
  }

  // 打开 PCM 设备
  int err = snd_pcm_open(&pcm_handle_, "default", SND_PCM_STREAM_CAPTURE, 0);
  if (err < 0) {
    RCLCPP_ERROR(this->get_logger(), "Cannot open audio device: %s", snd_strerror(err));
    return -1;
  }

  // 设置硬件参数
  snd_pcm_hw_params_t* hw_params;
  snd_pcm_hw_params_alloca(&hw_params);

  err = snd_pcm_hw_params_any(pcm_handle_, hw_params);
  if (err < 0) {
    RCLCPP_ERROR(this->get_logger(), "Cannot initialize hardware parameter structure: %s", snd_strerror(err));
    snd_pcm_close(pcm_handle_);
    pcm_handle_ = nullptr;
    return -1;
  }

  // 设置访问模式
  err = snd_pcm_hw_params_set_access(pcm_handle_, hw_params, SND_PCM_ACCESS_RW_INTERLEAVED);
  if (err < 0) {
    RCLCPP_ERROR(this->get_logger(), "Cannot set access type: %s", snd_strerror(err));
    snd_pcm_close(pcm_handle_);
    pcm_handle_ = nullptr;
    return -1;
  }

  // 设置采样格式
  err = snd_pcm_hw_params_set_format(pcm_handle_, hw_params, FORMAT);
  if (err < 0) {
    RCLCPP_ERROR(this->get_logger(), "Cannot set sample format: %s", snd_strerror(err));
    snd_pcm_close(pcm_handle_);
    pcm_handle_ = nullptr;
    return -1;
  }

  // 设置采样率
  unsigned int rate = SAMPLE_RATE;
  err = snd_pcm_hw_params_set_rate_near(pcm_handle_, hw_params, &rate, 0);
  if (err < 0) {
    RCLCPP_ERROR(this->get_logger(), "Cannot set sample rate: %s", snd_strerror(err));
    snd_pcm_close(pcm_handle_);
    pcm_handle_ = nullptr;
    return -1;
  }

  // 设置声道数
  err = snd_pcm_hw_params_set_channels(pcm_handle_, hw_params, CHANNELS);
  if (err < 0) {
    RCLCPP_ERROR(this->get_logger(), "Cannot set channel count: %s", snd_strerror(err));
    snd_pcm_close(pcm_handle_);
    pcm_handle_ = nullptr;
    return -1;
  }

  // 设置周期大小
  snd_pcm_uframes_t frames = FRAME_SIZE;
  err = snd_pcm_hw_params_set_period_size_near(pcm_handle_, hw_params, &frames, 0);
  if (err < 0) {
    RCLCPP_ERROR(this->get_logger(), "Cannot set period size: %s", snd_strerror(err));
    snd_pcm_close(pcm_handle_);
    pcm_handle_ = nullptr;
    return -1;
  }

  // 应用硬件参数
  err = snd_pcm_hw_params(pcm_handle_, hw_params);
  if (err < 0) {
    RCLCPP_ERROR(this->get_logger(), "Cannot set parameters: %s", snd_strerror(err));
    snd_pcm_close(pcm_handle_);
    pcm_handle_ = nullptr;
    return -1;
  }

  // 准备 PCM
  err = snd_pcm_prepare(pcm_handle_);
  if (err < 0) {
    RCLCPP_ERROR(this->get_logger(), "Cannot prepare audio interface for use: %s", snd_strerror(err));
    snd_pcm_close(pcm_handle_);
    pcm_handle_ = nullptr;
    return -1;
  }

  RCLCPP_INFO(this->get_logger(), "Audio device opened successfully");
  RCLCPP_INFO(this->get_logger(), "Sample rate: %u Hz, Channels: %u, Frame size: %u", SAMPLE_RATE, CHANNELS, FRAME_SIZE);

  // 启动捕获线程
  is_running_ = true;
  capture_thread_ = std::thread(&MicRecord::CaptureThread, this);

  return 0;
}

int MicRecord::Stop() {
  if (!is_running_) {
    return 0;
  }

  is_running_ = false;

  if (capture_thread_.joinable()) {
    capture_thread_.join();
  }

  if (pcm_handle_ != nullptr) {
    snd_pcm_drop(pcm_handle_);
    snd_pcm_close(pcm_handle_);
    pcm_handle_ = nullptr;
  }

  RCLCPP_INFO(this->get_logger(), "Audio capture stopped");
  return 0;
}

void MicRecord::CaptureThread() {
  const int buffer_size = FRAME_SIZE * CHANNELS;
  short* buffer = new short[buffer_size];

  RCLCPP_INFO(this->get_logger(), "Audio capture thread started");

  while (is_running_) {
    snd_pcm_sframes_t frames_read = snd_pcm_readi(pcm_handle_, buffer, FRAME_SIZE);

    if (frames_read < 0) {
      // 处理欠载或错误
      if (frames_read == -EPIPE) {
        RCLCPP_WARN(this->get_logger(), "Overrun occurred");
        snd_pcm_prepare(pcm_handle_);
      } else {
        RCLCPP_ERROR(this->get_logger(), "Read from audio interface failed: %s", snd_strerror(frames_read));
        break;
      }
    } else if (frames_read > 0) {
      // 发布音频数据
      PublishAudio(buffer, frames_read * CHANNELS * sizeof(short));
    }
  }

  delete[] buffer;
  RCLCPP_INFO(this->get_logger(), "Audio capture thread stopped");
}

void MicRecord::PublishAudio(const void* audio_data, int len) {
  if (audio_data == nullptr || len <= 0) {
    return;
  }

  auto msg = mic_interfaces::msg::AudioData();
  msg.data.resize(len);

  const uint8_t* data = static_cast<const uint8_t*>(audio_data);
  std::copy(data, data + len, msg.data.begin());

  audio_pub_->publish(msg);
}