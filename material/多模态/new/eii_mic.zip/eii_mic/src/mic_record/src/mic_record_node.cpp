#include "mic_record/mic_record.h"
#include "rclcpp/rclcpp.hpp"

int main(int argc, char* argv[]) {
  rclcpp::init(argc, argv);

  auto node = std::make_shared<MicRecord>("mic_record_node");

  // 开始音频捕获
  if (node->Start() != 0) {
    RCLCPP_ERROR(node->get_logger(), "Failed to start audio capture");
    return -1;
  }

  // 运行节点
  rclcpp::spin(node);

  // 停止音频捕获
  node->Stop();

  rclcpp::shutdown();
  return 0;
}
