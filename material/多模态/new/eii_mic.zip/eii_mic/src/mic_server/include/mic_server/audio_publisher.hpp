/**
 * @file audio_publisher.hpp
 * @brief 音频发布模块头文件
 *
 * 负责原始音频发布（从串口）
 */

#ifndef MIC_SERVER_AUDIO_PUBLISHER_HPP_
#define MIC_SERVER_AUDIO_PUBLISHER_HPP_

#include <atomic>
#include <memory>
#include <rclcpp/rclcpp.hpp>
#include <string>
#include <thread>
#include <vector>

#include "mic_interfaces/msg/audio_data.hpp"

namespace mic_server
{

// 前向声明
class SerialHandler;

/**
 * @brief 音频发布器类
 *
 * 负责从串口读取原始音频数据并发布到 ROS2 话题
 */
class AudioPublisher
{
public:
    /**
     * @brief 构造函数
     * @param node ROS2 节点指针
     * @param serial_handler 串口处理器指针
     */
    AudioPublisher(rclcpp::Node::SharedPtr node, std::shared_ptr<SerialHandler> serial_handler);

    /**
     * @brief 析构函数
     */
    ~AudioPublisher();

    /**
     * @brief 开始发布音频
     * @return 成功返回 true，失败返回 false
     */
    bool StartPublishing();

    /**
     * @brief 停止发布音频
     */
    void StopPublishing();

    /**
     * @brief 检查是否正在发布
     * @return 正在发布返回 true，否则返回 false
     */
    bool IsStreaming() const;

    /**
     * @brief 设置音频串口
     * @param audio_port 音频串口路径
     * @param baud_rate 波特率
     */
    void SetAudioPort(const std::string& audio_port, int baud_rate);

private:
    /**
     * @brief 从串口读取原始音频
     * @param audio_data 音频数据（输出）
     * @return 成功返回 true，失败返回 false
     */
    bool readOriginalAudio(std::vector<uint8_t> &audio_data);

    /**
     * @brief 发布音频帧
     * @param audio_data 音频数据
     */
    void publishAudioFrame(const std::vector<uint8_t> &audio_data);

    /**
     * @brief 原始音频发布线程函数
     */
    void originalAudioThreadFunc();

    // ROS2 节点指针
    rclcpp::Node::SharedPtr node_;

    // 串口处理器指针
    std::shared_ptr<SerialHandler> serial_handler_;

    // 原始音频发布者
    rclcpp::Publisher<mic_interfaces::msg::AudioData>::SharedPtr original_audio_pub_;

    // 音频串口（独立于交互串口）
    std::string audio_port_;
    int audio_baud_rate_;
    std::shared_ptr<SerialHandler> audio_serial_handler_;

    // 发布状态
    std::atomic<bool> is_streaming_;

    // 原始音频发布线程
    std::thread original_audio_thread_;
};

}    // namespace mic_server

#endif    // MIC_SERVER_AUDIO_PUBLISHER_HPP_
