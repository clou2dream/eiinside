/**
 * @file mic_server_node.hpp
 * @brief Mic Server 主节点头文件
 *
 * 负责 ROS2 节点初始化、参数加载、模块协调、服务注册和响应
 */

#ifndef MIC_SERVER_MIC_SERVER_NODE_HPP_
#define MIC_SERVER_MIC_SERVER_NODE_HPP_

#include <memory>
#include <mic_interfaces/srv/control_audio.hpp>
#include <mic_interfaces/srv/get_version.hpp>
#include <mic_interfaces/srv/manual_wakeup.hpp>
#include <mic_interfaces/srv/set_wakeup_keyword.hpp>
#include <rclcpp/rclcpp.hpp>
#include <string>

namespace mic_server
{

// 前向声明
class SerialHandler;
class AudioPublisher;
class WakeupHandler;

/**
 * @brief Mic Server 主节点类
 *
 * 协调各模块工作，提供 ROS2 服务和话题接口
 */
class MicServerNode
{
public:
    /**
     * @brief 构造函数
     */
    MicServerNode();

    /**
     * @brief 析构函数
     */
    ~MicServerNode();

    /**
     * @brief 初始化节点
     * @return 成功返回 true，失败返回 false
     */
    bool Initialize();

    /**
     * @brief 运行节点主循环
     */
    void Run();

    /**
     * @brief 关闭节点
     */
    void Shutdown();

private:
    /**
     * @brief 加载参数
     */
    void loadParameters();

    /**
     * @brief 注册服务
     */
    void setupServices();

    /**
     * @brief 设置定时器
     */
    void setupTimer();

    /**
     * @brief 处理串口数据（定时器回调）
     */
    void handleSerialData();

    /**
     * @brief 处理获取版本服务请求
     */
    void handleGetVersion(
        const std::shared_ptr<mic_interfaces::srv::GetVersion::Request> request,
        std::shared_ptr<mic_interfaces::srv::GetVersion::Response> response);

    /**
     * @brief 处理音频控制服务请求
     */
    void handleControlAudio(
        const std::shared_ptr<mic_interfaces::srv::ControlAudio::Request> request,
        std::shared_ptr<mic_interfaces::srv::ControlAudio::Response> response);

    /**
     * @brief 处理手动唤醒服务请求
     */
    void handleManualWakeup(
        const std::shared_ptr<mic_interfaces::srv::ManualWakeup::Request> request,
        std::shared_ptr<mic_interfaces::srv::ManualWakeup::Response> response);

    /**
     * @brief 处理设置唤醒关键词服务请求
     */
    void handleSetWakeupKeyword(
        const std::shared_ptr<mic_interfaces::srv::SetWakeupKeyword::Request> request,
        std::shared_ptr<mic_interfaces::srv::SetWakeupKeyword::Response> response);

    // ROS2 节点
    rclcpp::Node::SharedPtr node_;

    // 串口处理器
    std::shared_ptr<SerialHandler> serial_handler_;

    // 音频发布器
    std::shared_ptr<AudioPublisher> audio_publisher_;

    // 唤醒处理器
    std::shared_ptr<WakeupHandler> wakeup_handler_;

    // 服务
    rclcpp::Service<mic_interfaces::srv::GetVersion>::SharedPtr get_version_srv_;
    rclcpp::Service<mic_interfaces::srv::ControlAudio>::SharedPtr control_audio_srv_;
    rclcpp::Service<mic_interfaces::srv::ManualWakeup>::SharedPtr manual_wakeup_srv_;
    rclcpp::Service<mic_interfaces::srv::SetWakeupKeyword>::SharedPtr set_keyword_srv_;

    // 定时器
    rclcpp::TimerBase::SharedPtr serial_timer_;

    // 参数
    std::string control_port_;    // 交互串口
    std::string audio_port_;      // 音频串口
    int baud_rate_;

    // 运行状态
    bool initialized_;
};

}    // namespace mic_server

#endif    // MIC_SERVER_MIC_SERVER_NODE_HPP_
