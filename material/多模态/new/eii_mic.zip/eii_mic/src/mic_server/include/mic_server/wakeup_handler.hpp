/**
 * @file wakeup_handler.hpp
 * @brief 唤醒处理模块头文件
 *
 * 负责唤醒事件解析和发布、响应手动唤醒请求、管理唤醒关键词
 */

#ifndef MIC_SERVER_WAKEUP_HANDLER_HPP_
#define MIC_SERVER_WAKEUP_HANDLER_HPP_

#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/string.hpp>
#include <mic_interfaces/srv/manual_wakeup.hpp>
#include <mic_interfaces/srv/set_wakeup_keyword.hpp>
#include <memory>
#include <string>
#include <functional>

namespace mic_server
{

// 前向声明
class SerialHandler;

/**
 * @brief 唤醒处理器类
 *
 * 负责处理唤醒事件、手动唤醒请求和唤醒关键词管理
 */
class WakeupHandler
{
public:
    /**
     * @brief 构造函数
     * @param node ROS2节点指针
     * @param serial_handler 串口处理器指针
     */
    WakeupHandler(rclcpp::Node::SharedPtr node, std::shared_ptr<SerialHandler> serial_handler);

    /**
     * @brief 析构函数
     */
    ~WakeupHandler();

    /**
     * @brief 处理唤醒消息
     * @param data 唤醒消息数据
     */
    void HandleWakeupMessage(const std::vector<uint8_t>& data);

    /**
     * @brief 触发手动唤醒
     * @param beam 波束方向
     * @param success 是否成功（输出）
     * @param message 结果说明（输出）
     */
    void TriggerManualWakeup(int32_t beam, bool& success, std::string& message);

    /**
     * @brief 设置唤醒关键词
     * @param keyword 唤醒关键词
     * @param threshold 阈值
     * @param success 是否成功（输出）
     * @param message 结果说明（输出）
     */
    void SetKeyword(const std::string& keyword, int32_t threshold, bool& success, std::string& message);

private:

    // ROS2节点指针
    rclcpp::Node::SharedPtr node_;

    // 串口处理器指针
    std::shared_ptr<SerialHandler> serial_handler_;

    // 唤醒事件发布者
    rclcpp::Publisher<std_msgs::msg::String>::SharedPtr wakeup_pub_;

    // 当前唤醒关键词
    std::string keyword_;

    // 当前阈值
    int32_t threshold_;
};

}  // namespace mic_server

#endif  // MIC_SERVER_WAKEUP_HANDLER_HPP_
