/**
 * @file audio_publisher.cpp
 * @brief 音频发布模块实现
 */

#include "mic_server/audio_publisher.hpp"

#include <chrono>
#include <cstring>

#include "mic_server/serial_handler.hpp"

namespace mic_server
{

AudioPublisher::AudioPublisher(rclcpp::Node::SharedPtr node,
                               std::shared_ptr<SerialHandler> serial_handler)
    : node_(node),
      serial_handler_(serial_handler),
      audio_baud_rate_(0),
      is_streaming_(false)
{
    // 创建原始音频发布者
    original_audio_pub_ = node_->create_publisher<mic_interfaces::msg::AudioData>(
        "/mic/original_audio", rclcpp::QoS(10));
}

AudioPublisher::~AudioPublisher()
{
    StopPublishing();

    // 关闭音频串口
    if (audio_serial_handler_)
    {
        audio_serial_handler_->CloseSerial();
    }
}

void AudioPublisher::SetAudioPort(const std::string& audio_port, int baud_rate)
{
    audio_port_ = audio_port;
    audio_baud_rate_ = baud_rate;

    // 创建独立的音频串口处理器
    audio_serial_handler_ = std::make_shared<SerialHandler>();
}

bool AudioPublisher::StartPublishing()
{
    if (is_streaming_)
    {
        return true;
    }

    // 1. 发送启动音频命令到设备（通过交互串口）
    if (!serial_handler_ || !serial_handler_->IsOpen())
    {
        RCLCPP_ERROR(node_->get_logger(), "交互串口未打开");
        return false;
    }

    // 构造JSON命令：{"type":"get_original_audio","content":{"audio":1}}
    std::string json_cmd = R"({"type":"get_original_audio","content":{"audio":1}})";
    std::vector<uint8_t> cmd_data(json_cmd.begin(), json_cmd.end());

    RCLCPP_INFO(node_->get_logger(), "发送启动音频命令...");
    SerialMessage response;
    bool cmd_success = serial_handler_->SendCommand(MANUAL_WAKEUP_TYPE, cmd_data, response, 5.0);

    if (!cmd_success)
    {
        RCLCPP_ERROR(node_->get_logger(), "启动音频命令发送失败或超时");
        return false;
    }

    // 检查响应是否成功
    std::string resp_str(response.data.begin(), response.data.end());
    if (resp_str.find("\"code\":0") == std::string::npos ||
        resp_str.find("\"success\"") == std::string::npos)
    {
        RCLCPP_ERROR(node_->get_logger(), "设备未确认启动音频：%s", resp_str.c_str());
        return false;
    }

    RCLCPP_INFO(node_->get_logger(), "设备已确认启动音频");

    // 2. 打开音频串口
    if (!audio_serial_handler_ || audio_port_.empty())
    {
        RCLCPP_ERROR(node_->get_logger(), "音频串口未配置");
        return false;
    }

    RCLCPP_INFO(node_->get_logger(), "打开音频串口：%s", audio_port_.c_str());
    if (!audio_serial_handler_->OpenSerial(audio_port_, audio_baud_rate_))
    {
        RCLCPP_ERROR(node_->get_logger(), "无法打开音频串口：%s", audio_port_.c_str());
        return false;
    }

    is_streaming_ = true;

    // 3. 启动原始音频发布线程
    original_audio_thread_ = std::thread(&AudioPublisher::originalAudioThreadFunc, this);

    RCLCPP_INFO(node_->get_logger(), "音频发布已启动");
    return true;
}

void AudioPublisher::StopPublishing()
{
    if (!is_streaming_)
    {
        return;
    }

    is_streaming_ = false;

    // 1. 发送停止音频命令到设备（通过交互串口）
    if (serial_handler_ && serial_handler_->IsOpen())
    {
        // 构造JSON命令：{"type":"get_original_audio","content":{"audio":0}}
        std::string json_cmd = R"({"type":"get_original_audio","content":{"audio":0}})";
        std::vector<uint8_t> cmd_data(json_cmd.begin(), json_cmd.end());

        RCLCPP_INFO(node_->get_logger(), "发送停止音频命令...");
        SerialMessage response;
        serial_handler_->SendCommand(MANUAL_WAKEUP_TYPE, cmd_data, response, 2.0);
    }

    // 2. 等待线程结束
    if (original_audio_thread_.joinable())
    {
        original_audio_thread_.join();
    }

    // 3. 关闭音频串口
    if (audio_serial_handler_)
    {
        audio_serial_handler_->CloseSerial();
    }

    RCLCPP_INFO(node_->get_logger(), "音频发布已停止");
}

bool AudioPublisher::IsStreaming() const
{
    return is_streaming_;
}

bool AudioPublisher::readOriginalAudio(std::vector<uint8_t> &audio_data)
{
    if (!audio_serial_handler_ || !audio_serial_handler_->IsOpen())
    {
        return false;
    }

    // 从音频串口读取音频消息
    SerialMessage msg;
    if (audio_serial_handler_->ReadMessage(msg))
    {
        if (msg.type == AUDIO_DATA_TYPE)
        {
            audio_data = msg.data;
            return true;
        }
    }

    return false;
}

void AudioPublisher::publishAudioFrame(const std::vector<uint8_t> &audio_data)
{
    auto msg = mic_interfaces::msg::AudioData();
    msg.data.resize(audio_data.size());
    std::copy(audio_data.begin(), audio_data.end(), msg.data.begin());

    original_audio_pub_->publish(msg);
}

void AudioPublisher::originalAudioThreadFunc()
{
    while (is_streaming_)
    {
        std::vector<uint8_t> audio_data;
        if (readOriginalAudio(audio_data))
        {
            publishAudioFrame(audio_data);
        }
        else
        {
            // 短暂休眠避免 CPU 占用过高
            std::this_thread::sleep_for(std::chrono::milliseconds(1));
        }
    }
}

}    // namespace mic_server
