/**
 * @file main.cpp
 * @brief Mic Server程序入口
 */

#include "mic_server/mic_server_node.hpp"
#include <rclcpp/rclcpp.hpp>

int main(int argc, char** argv)
{
    // 初始化ROS2
    rclcpp::init(argc, argv);

    // 创建并初始化节点
    mic_server::MicServerNode node;
    if (!node.Initialize())
    {
        RCLCPP_ERROR(rclcpp::get_logger("mic_server"), "节点初始化失败");
        rclcpp::shutdown();
        return 1;
    }

    // 运行节点
    node.Run();

    // 关闭ROS2
    rclcpp::shutdown();
    return 0;
}
