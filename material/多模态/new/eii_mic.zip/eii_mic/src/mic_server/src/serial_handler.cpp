/**
 * @file serial_handler.cpp
 * @brief 串口处理模块实现
 */

#include "mic_server/serial_handler.hpp"
#include <rclcpp/rclcpp.hpp>
#include <fcntl.h>
#include <termios.h>
#include <unistd.h>
#include <cstring>
#include <chrono>
#include <stdexcept>

namespace mic_server
{

SerialHandler::SerialHandler()
    : serial_fd_(-1), message_id_(100), last_received_msg_id_(0)
{
}

SerialHandler::~SerialHandler()
{
    CloseSerial();
}

bool SerialHandler::OpenSerial(const std::string& port_name, int baudrate)
{
    // 如果已经打开，先关闭
    CloseSerial();

    // 打开串口设备
    serial_fd_ = open(port_name.c_str(), O_RDWR | O_NOCTTY | O_NONBLOCK);
    if (serial_fd_ < 0)
    {
        return false;
    }

    // 配置串口参数
    struct termios tty;
    memset(&tty, 0, sizeof(tty));

    if (tcgetattr(serial_fd_, &tty) != 0)
    {
        close(serial_fd_);
        serial_fd_ = -1;
        return false;
    }

    // 设置波特率
    speed_t speed = B115200;
    switch (baudrate)
    {
        case 9600:   speed = B9600; break;
        case 19200:  speed = B19200; break;
        case 38400:  speed = B38400; break;
        case 57600:  speed = B57600; break;
        case 115200: speed = B115200; break;
        default:     speed = B115200; break;
    }
    cfsetospeed(&tty, speed);
    cfsetispeed(&tty, speed);

    // 8N1配置
    tty.c_cflag &= ~PARENB;   // 无奇偶校验
    tty.c_cflag &= ~CSTOPB;   // 1位停止位
    tty.c_cflag &= ~CSIZE;    // 清除数据位设置
    tty.c_cflag |= CS8;       // 8位数据位
    tty.c_cflag &= ~CRTSCTS;  // 无硬件流控
    tty.c_cflag |= CREAD | CLOCAL;  // 启用接收，忽略调制解调器控制线

    // 原始输入模式
    tty.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);
    tty.c_iflag &= ~(IXON | IXOFF | IXANY);
    tty.c_iflag &= ~(IGNBRK | BRKINT | PARMRK | ISTRIP | INLCR | IGNCR | ICRNL);

    // 原始输出模式
    tty.c_oflag &= ~OPOST;

    // 设置超时（VTIME=0, VMIN=0表示非阻塞）
    tty.c_cc[VMIN] = 0;
    tty.c_cc[VTIME] = 0;

    if (tcsetattr(serial_fd_, TCSANOW, &tty) != 0)
    {
        close(serial_fd_);
        serial_fd_ = -1;
        return false;
    }

    // 清空缓冲区
    tcflush(serial_fd_, TCIOFLUSH);

    port_name_ = port_name;
    return true;
}

void SerialHandler::CloseSerial()
{
    if (serial_fd_ >= 0)
    {
        close(serial_fd_);
        serial_fd_ = -1;
    }
    recv_buffer_.clear();
    port_name_.clear();
}

bool SerialHandler::WaitAndHandshake(double timeout_sec)
{
    if (serial_fd_ < 0)
    {
        return false;
    }

    auto start_time = std::chrono::steady_clock::now();

    // 等待设备发送握手消息
    while (true)
    {
        // 检查超时
        auto now = std::chrono::steady_clock::now();
        auto elapsed = std::chrono::duration<double>(now - start_time).count();
        if (elapsed >= timeout_sec)
        {
            // 设备握手成功后只要不断电就不需要再次握手
            // 超时未收到握手消息说明设备已经握手过，直接返回成功
            return true;
        }

        // 尝试读取消息
        SerialMessage msg;
        if (ReadMessage(msg))
        {
            // 检查是否是握手消息
            if (msg.type == HANDSHAKE_MSG_TYPE)
            {
                // 验证握手数据：期望 0xA5, 0x00, 0x00, 0x00
                if (msg.data.size() == 4 &&
                    msg.data[0] == 0xA5 &&
                    msg.data[1] == 0x00 &&
                    msg.data[2] == 0x00 &&
                    msg.data[3] == 0x00)
                {
                    uint16_t msg_id = last_received_msg_id_;

                    // 发送握手确认响应
                    SerialMessage ack_msg;
                    ack_msg.type = HANDSHAKE_ACK_TYPE;
                    ack_msg.length = 4;
                    ack_msg.data = {0xA5, 0x00, 0x00, 0x00};

                    std::vector<uint8_t> encoded = encodeMessage(ack_msg, msg_id);
                    ssize_t written = write(serial_fd_, encoded.data(), encoded.size());
                    if (written == static_cast<ssize_t>(encoded.size()))
                    {
                        return true;
                    }
                }
            }
        }

        // 短暂休眠避免CPU占用过高
        usleep(10000);  // 10ms
    }
}

bool SerialHandler::SendCommand(uint8_t msg_type, const std::vector<uint8_t>& data,
                                SerialMessage& response, double timeout_sec)
{
    if (serial_fd_ < 0)
    {
        return false;
    }

    auto start_time = std::chrono::steady_clock::now();

    // 构造并发送消息
    SerialMessage msg;
    msg.type = msg_type;
    msg.length = static_cast<uint16_t>(data.size());
    msg.data = data;

    uint16_t msg_id = message_id_++;
    std::vector<uint8_t> encoded = encodeMessage(msg, msg_id);
    ssize_t written = write(serial_fd_, encoded.data(), encoded.size());
    if (written != static_cast<ssize_t>(encoded.size()))
    {
        return false;
    }

    // 等待响应
    while (true)
    {
        auto now = std::chrono::steady_clock::now();
        auto elapsed = std::chrono::duration<double>(now - start_time).count();
        if (elapsed >= timeout_sec)
        {
            return false;
        }

        if (ReadMessage(response))
        {
            return true;
        }

        usleep(10000);  // 10ms
    }
}

bool SerialHandler::ReadMessage(SerialMessage& msg)
{
    if (serial_fd_ < 0)
    {
        return false;
    }

    // 读取可用数据到缓冲区
    uint8_t temp_buf[4096];
    ssize_t bytes_read = read(serial_fd_, temp_buf, sizeof(temp_buf));
    if (bytes_read > 0)
    {
        recv_buffer_.insert(recv_buffer_.end(), temp_buf, temp_buf + bytes_read);
    }

    // 检查是否有足够的头部数据
    if (recv_buffer_.size() < HEADER_SIZE)
    {
        return false;
    }

    // 查找同步头
    size_t sync_pos = 0;
    bool found_sync = false;
    for (size_t i = 0; i < recv_buffer_.size(); ++i)
    {
        if (recv_buffer_[i] == SYNC_HEADER)
        {
            sync_pos = i;
            found_sync = true;
            break;
        }
    }

    // 移除同步头之前的无效数据
    if (!found_sync)
    {
        recv_buffer_.clear();
        return false;
    }

    if (sync_pos > 0)
    {
        recv_buffer_.erase(recv_buffer_.begin(), recv_buffer_.begin() + sync_pos);
    }

    // 再次检查头部是否完整
    if (recv_buffer_.size() < HEADER_SIZE)
    {
        return false;
    }

    // 解析头部
    uint8_t msg_type;
    uint16_t data_len;
    std::vector<uint8_t> header(recv_buffer_.begin(), recv_buffer_.begin() + HEADER_SIZE);
    if (!parseHeader(header, msg_type, data_len))
    {
        // 头部解析失败，丢弃第一个字节继续查找
        recv_buffer_.erase(recv_buffer_.begin());
        return false;
    }

    // 检查是否有完整消息（头部 + 数据 + 校验码）
    size_t total_len = HEADER_SIZE + data_len + 1;
    if (recv_buffer_.size() < total_len)
    {
        return false;
    }

    // 提取完整消息
    std::vector<uint8_t> full_msg(recv_buffer_.begin(), recv_buffer_.begin() + total_len);
    recv_buffer_.erase(recv_buffer_.begin(), recv_buffer_.begin() + total_len);

    // 验证消息
    if (!validateMessage(full_msg))
    {
        return false;
    }

    // 提取msg_id（小端序）
    last_received_msg_id_ = static_cast<uint16_t>(full_msg[5] | (full_msg[6] << 8));

    // 填充消息结构
    msg.type = msg_type;
    msg.length = data_len;
    msg.data.assign(full_msg.begin() + HEADER_SIZE, full_msg.begin() + HEADER_SIZE + data_len);

    return true;
}

bool SerialHandler::IsOpen() const
{
    return serial_fd_ >= 0;
}

uint8_t SerialHandler::calculateChecksum(const std::vector<uint8_t>& data)
{
    uint8_t checksum = 0;
    for (uint8_t byte : data)
    {
        checksum += byte;
    }
    // 二进制补码：((~sum) + 1) & 0xFF
    return ((~checksum) + 1) & 0xFF;
}

std::vector<uint8_t> SerialHandler::encodeMessage(const SerialMessage& msg)
{
    return encodeMessage(msg, message_id_++);
}

std::vector<uint8_t> SerialHandler::encodeMessage(const SerialMessage& msg, uint16_t msg_id)
{
    std::vector<uint8_t> result;

    // 同步头
    result.push_back(SYNC_HEADER);

    // 用户ID
    result.push_back(USER_ID);

    // 消息类型
    result.push_back(msg.type);

    // 数据长度（小端序）
    result.push_back(static_cast<uint8_t>(msg.length & 0xFF));
    result.push_back(static_cast<uint8_t>((msg.length >> 8) & 0xFF));

    // 消息ID（小端序）
    result.push_back(static_cast<uint8_t>(msg_id & 0xFF));
    result.push_back(static_cast<uint8_t>((msg_id >> 8) & 0xFF));

    // 数据内容
    result.insert(result.end(), msg.data.begin(), msg.data.end());

    // 校验码（二进制补码）- 计算除最后一个字节外的所有数据
    uint8_t checksum = calculateChecksum(result);
    result.push_back(checksum);

    return result;
}

bool SerialHandler::parseHeader(const std::vector<uint8_t>& header, uint8_t& msg_type, uint16_t& data_len)
{
    if (header.size() < HEADER_SIZE)
    {
        return false;
    }

    // 验证同步头
    if (header[0] != SYNC_HEADER)
    {
        return false;
    }

    // 提取消息类型
    msg_type = header[2];

    // 提取数据长度（小端序）
    data_len = static_cast<uint16_t>(header[3] | (header[4] << 8));

    return true;
}

bool SerialHandler::validateMessage(const std::vector<uint8_t>& data)
{
    if (data.size() < HEADER_SIZE + 1)
    {
        return false;
    }

    // 提取校验码（最后一个字节）
    uint8_t received_checksum = data.back();

    // 计算期望的校验码
    uint8_t expected_checksum = 0;
    for (size_t i = 0; i < data.size() - 1; ++i)
    {
        expected_checksum += data[i];
    }
    expected_checksum = ((~expected_checksum) + 1) & 0xFF;

    return received_checksum == expected_checksum;
}

}  // namespace mic_server
