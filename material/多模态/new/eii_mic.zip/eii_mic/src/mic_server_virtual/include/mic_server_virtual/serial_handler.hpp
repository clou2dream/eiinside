/**
 * @file serial_handler.hpp
 * @brief 串口处理模块头文件
 *
 * 负责串口连接管理、握手流程执行、协议编码/解码、消息发送与接收
 */

#ifndef MIC_SERVER_VIRTUAL_SERIAL_HANDLER_HPP_
#define MIC_SERVER_VIRTUAL_SERIAL_HANDLER_HPP_

#include <cstdint>
#include <string>
#include <vector>

namespace mic_server_virtual
{

// 协议常量定义
constexpr uint8_t SYNC_HEADER = 0xA5;         // 同步头
constexpr uint8_t USER_ID = 0x01;             // 用户ID
constexpr uint8_t WAKEUP_MSG_TYPE = 0x04;     // 唤醒消息类型
constexpr uint8_t MANUAL_WAKEUP_TYPE = 0x05;  // 手动唤醒类型
constexpr uint8_t AUDIO_DATA_TYPE = 0x06;     // 音频数据类型
constexpr uint8_t HANDSHAKE_MSG_TYPE = 0x01;  // 握手消息类型
constexpr uint8_t HANDSHAKE_ACK_TYPE = 0xFF;  // 握手确认类型
constexpr uint8_t HEADER_SIZE = 7;            // 消息头大小

/**
 * @brief 串口消息结构体
 */
struct SerialMessage
{
    uint8_t type;                   // 消息类型
    uint16_t length;                // 数据长度
    std::vector<uint8_t> data;      // 数据内容
};

/**
 * @brief 串口处理类
 *
 * 负责串口通信的底层操作，包括连接管理、协议编解码、消息收发
 */
class SerialHandler
{
public:
    /**
     * @brief 构造函数
     */
    SerialHandler();

    /**
     * @brief 析构函数
     */
    ~SerialHandler();

    /**
     * @brief 打开串口
     * @param port_name 串口设备路径
     * @param baudrate 波特率
     * @return 成功返回true，失败返回false
     */
    bool OpenSerial(const std::string& port_name, int baudrate);

    /**
     * @brief 关闭串口
     */
    void CloseSerial();

    /**
     * @brief 执行握手流程
     * @param timeout_sec 握手超时时间（秒）
     * @return 成功返回true，超时或失败返回false
     */
    bool WaitAndHandshake(double timeout_sec);

    /**
     * @brief 发送命令并等待响应
     * @param msg_type 消息类型
     * @param data 命令数据
     * @param response 响应消息（输出）
     * @param timeout_sec 超时时间（秒）
     * @return 成功返回true，超时或失败返回false
     */
    bool SendCommand(uint8_t msg_type, const std::vector<uint8_t>& data,
                     SerialMessage& response, double timeout_sec);

    /**
     * @brief 读取一条消息（非阻塞）
     * @param msg 读取的消息（输出）
     * @return 成功读取返回true，无数据或失败返回false
     */
    bool ReadMessage(SerialMessage& msg);

    /**
     * @brief 检查串口是否已打开
     * @return 已打开返回true，否则返回false
     */
    bool IsOpen() const;

private:
    /**
     * @brief 计算校验码
     * @param data 数据内容
     * @return 校验码
     */
    uint8_t calculateChecksum(const std::vector<uint8_t>& data);

    /**
     * @brief 编码消息为字节流
     * @param msg 消息结构
     * @return 编码后的字节流
     */
    std::vector<uint8_t> encodeMessage(const SerialMessage& msg);

    /**
     * @brief 编码消息为字节流（带消息ID）
     * @param msg 消息结构
     * @param msg_id 消息ID
     * @return 编码后的字节流
     */
    std::vector<uint8_t> encodeMessage(const SerialMessage& msg, uint16_t msg_id);

    /**
     * @brief 解析消息头
     * @param header 头部字节（7字节）
     * @param msg_type 消息类型（输出）
     * @param data_len 数据长度（输出）
     * @return 解析成功返回true，失败返回false
     */
    bool parseHeader(const std::vector<uint8_t>& header, uint8_t& msg_type, uint16_t& data_len);

    /**
     * @brief 验证消息完整性
     * @param data 完整消息数据（含头部和数据）
     * @return 验证通过返回true，失败返回false
     */
    bool validateMessage(const std::vector<uint8_t>& data);

    /**
     * @brief 解析消息头，获取消息ID
     * @param header 头部字节（7字节）
     * @param msg_id 消息ID（输出）
     * @return 解析成功返回true，失败返回false
     */
    bool parseMsgId(const std::vector<uint8_t>& header, uint16_t& msg_id);

    // 串口文件描述符
    int serial_fd_;

    // 串口设备名
    std::string port_name_;

    // 接收缓冲区
    std::vector<uint8_t> recv_buffer_;

    // 消息ID（用于握手响应）
    uint16_t message_id_;

    // 最后接收到的消息ID
    uint16_t last_received_msg_id_;
};

}  // namespace mic_server_virtual

#endif  // MIC_SERVER_VIRTUAL_SERIAL_HANDLER_HPP_
