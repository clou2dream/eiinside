#!/usr/bin/env python3
"""
Mic Server启动文件
"""

from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from ament_index_python.packages import get_package_share_directory
import os


def generate_launch_description():
    # 获取包路径
    pkg_share = get_package_share_directory('mic_server_virtual')

    # 配置文件路径
    config_file = os.path.join(pkg_share, 'config', 'mic_params.yaml')

    # 声明参数
    config_arg = DeclareLaunchArgument(
        'config_file',
        default_value=config_file,
        description='Path to the config file'
    )

    # 创建节点
    mic_server_node = Node(
        package='mic_server_virtual',
        executable='mic_server_virtual_node_exe',
        name='mic_server_virtual',
        output='screen',
        parameters=[LaunchConfiguration('config_file')],
        emulate_tty=True,
    )

    return LaunchDescription([
        config_arg,
        mic_server_node,
    ])
