/**
 * @file main.cpp
 * @brief Mic Server程序入口
 */

#include "mic_server_virtual/mic_server_node.hpp"
#include <rclcpp/rclcpp.hpp>

int main(int argc, char** argv)
{
    rclcpp::init(argc, argv);
    mic_server_virtual::MicServerNode node;
    if (!node.Initialize())
    {
        RCLCPP_ERROR(rclcpp::get_logger("mic_server_virtual"), "节点初始化失败");
        rclcpp::shutdown();
        return 1;
    }
    node.Run();
    rclcpp::shutdown();
    return 0;
}
