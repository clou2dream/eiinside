/**
 * @file mic_server_node.cpp
 * @brief Mic Server 主节点实现
 */

#include "mic_server_virtual/mic_server_node.hpp"

#include "mic_server_virtual/audio_publisher.hpp"
#include "mic_server_virtual/serial_handler.hpp"
#include "mic_server_virtual/wakeup_handler.hpp"

namespace mic_server_virtual
{

MicServerNode::MicServerNode()
    : serial_port_(), baud_rate_(0), initialized_(false)
{
}

MicServerNode::~MicServerNode()
{
    Shutdown();
}

bool MicServerNode::Initialize()
{
    if (initialized_)
    {
        return true;
    }

    // 创建 ROS2 节点
    node_ = rclcpp::Node::make_shared("mic_server_virtual");

    // 加载参数
    loadParameters();

    // 创建串口处理器
    serial_handler_ = std::make_shared<SerialHandler>();

    // 打开串口（交互 + 音频）
    RCLCPP_INFO(node_->get_logger(), "打开串口：%s", serial_port_.c_str());
    if (!serial_handler_->OpenSerial(serial_port_, baud_rate_))
    {
        RCLCPP_ERROR(node_->get_logger(), "无法打开串口：%s", serial_port_.c_str());
        return false;
    }

    // 执行握手
    RCLCPP_INFO(node_->get_logger(), "执行握手...");
    if (!serial_handler_->WaitAndHandshake(5.0))
    {
        RCLCPP_ERROR(node_->get_logger(), "握手失败");
        return false;
    }
    RCLCPP_INFO(node_->get_logger(), "握手成功");

    // 创建音频发布器（使用共享串口）
    audio_publisher_ = std::make_shared<AudioPublisher>(node_, serial_handler_);

    // 创建唤醒处理器
    wakeup_handler_ = std::make_shared<WakeupHandler>(node_, serial_handler_);

    // 设置服务
    setupServices();

    // 设置定时器
    setupTimer();

    initialized_ = true;
    RCLCPP_INFO(node_->get_logger(), "Mic Server 初始化完成");
    return true;
}

void MicServerNode::Run()
{
    if (!initialized_)
    {
        RCLCPP_ERROR(rclcpp::get_logger("mic_server_virtual"), "节点未初始化");
        return;
    }

    rclcpp::spin(node_);
}

void MicServerNode::Shutdown()
{
    if (!initialized_)
    {
        return;
    }

    RCLCPP_INFO(node_->get_logger(), "关闭 Mic Server...");

    // 停止音频发布
    if (audio_publisher_)
    {
        audio_publisher_->StopPublishing();
    }

    // 关闭串口
    if (serial_handler_)
    {
        serial_handler_->CloseSerial();
    }

    initialized_ = false;
    RCLCPP_INFO(node_->get_logger(), "Mic Server 已关闭");
}

void MicServerNode::loadParameters()
{
    // 串口参数
    serial_port_ = node_->declare_parameter<std::string>("serial_port", "/dev/ttyACM0");
    baud_rate_   = node_->declare_parameter<int>("baud_rate", 115200);

    RCLCPP_INFO(node_->get_logger(), "参数加载完成:");
    RCLCPP_INFO(node_->get_logger(), "  串口：%s", serial_port_.c_str());
    RCLCPP_INFO(node_->get_logger(), "  波特率：%d", baud_rate_);
}

void MicServerNode::setupServices()
{
    // 获取版本服务
    get_version_srv_ = node_->create_service<mic_interfaces::srv::GetVersion>("/mic/get_version", std::bind(&MicServerNode::handleGetVersion, this, std::placeholders::_1, std::placeholders::_2));

    // 音频控制服务
    control_audio_srv_ = node_->create_service<mic_interfaces::srv::ControlAudio>("/mic/control_audio", std::bind(&MicServerNode::handleControlAudio, this, std::placeholders::_1, std::placeholders::_2));

    // 手动唤醒服务
    manual_wakeup_srv_ = node_->create_service<mic_interfaces::srv::ManualWakeup>("/mic/manual_wakeup", std::bind(&MicServerNode::handleManualWakeup, this, std::placeholders::_1, std::placeholders::_2));
    
    // 设置唤醒关键词服务
    set_keyword_srv_ = node_->create_service<mic_interfaces::srv::SetWakeupKeyword>("/mic/set_wakeup_keyword", std::bind(&MicServerNode::handleSetWakeupKeyword, this, std::placeholders::_1, std::placeholders::_2));

    RCLCPP_INFO(node_->get_logger(), "服务注册完成");
}

void MicServerNode::setupTimer()
{
    // 创建串口数据读取定时器（10ms 周期）
    serial_timer_ = node_->create_wall_timer(
        std::chrono::milliseconds(10),
        std::bind(&MicServerNode::handleSerialData, this));
}

void MicServerNode::handleSerialData()
{
    if (!serial_handler_ || !serial_handler_->IsOpen())
    {
        return;
    }

    // 读取串口消息
    SerialMessage msg;
    while (serial_handler_->ReadMessage(msg))
    {
        switch (msg.type)
        {
            case WAKEUP_MSG_TYPE:
                // 处理唤醒消息
                if (wakeup_handler_)
                {
                    wakeup_handler_->HandleWakeupMessage(msg.data);
                }
                break;

            case AUDIO_DATA_TYPE:
                // 音频数据由 AudioPublisher 处理
                break;

            default:
                RCLCPP_DEBUG(node_->get_logger(), "收到未知消息类型：0x%02X", msg.type);
                break;
        }
    }
}

void MicServerNode::handleGetVersion(const std::shared_ptr<mic_interfaces::srv::GetVersion::Request> request, std::shared_ptr<mic_interfaces::srv::GetVersion::Response> response)
{
    (void)request;    // 未使用的参数

    // 构造JSON命令：{"type": "version"}
    std::string json_cmd = R"({"type":"version"})";
    std::vector<uint8_t> cmd_data(json_cmd.begin(), json_cmd.end());

    // 发送获取版本命令（使用MANUAL_WAKEUP_TYPE = 0x05）
    SerialMessage cmd_response;
    bool success = serial_handler_->SendCommand(MANUAL_WAKEUP_TYPE, cmd_data, cmd_response, 5.0);

    if (success && cmd_response.data.size() > 0)
    {
        // 解析版本信息（响应也是JSON格式）
        std::string version(cmd_response.data.begin(), cmd_response.data.end());
        response->success = true;
        response->version = version;
        response->message = "获取版本成功";
    }
    else
    {
        response->success = false;
        response->version = "";
        response->message = "获取版本失败或超时";
    }
}

void MicServerNode::handleControlAudio(const std::shared_ptr<mic_interfaces::srv::ControlAudio::Request> request, std::shared_ptr<mic_interfaces::srv::ControlAudio::Response> response)
{
    if (request->enable)
    {
        if (audio_publisher_->StartPublishing())
        {
            response->success = true;
            response->message = "音频发布已启动";
        }
        else
        {
            response->success = false;
            response->message = "音频发布启动失败";
        }
    }
    else
    {
        audio_publisher_->StopPublishing();
        response->success = true;
        response->message = "音频发布已停止";
    }
}

void MicServerNode::handleManualWakeup(const std::shared_ptr<mic_interfaces::srv::ManualWakeup::Request> request, std::shared_ptr<mic_interfaces::srv::ManualWakeup::Response> response)
{
    if (wakeup_handler_)
    {
        wakeup_handler_->TriggerManualWakeup(request->beam, response->success, response->message);
    }
    else
    {
        response->success = false;
        response->message = "唤醒处理器未初始化";
    }
}

void MicServerNode::handleSetWakeupKeyword(const std::shared_ptr<mic_interfaces::srv::SetWakeupKeyword::Request> request, std::shared_ptr<mic_interfaces::srv::SetWakeupKeyword::Response> response)
{
    // 检查唤醒词是否为空
    if (request->keyword.empty())
    {
        response->success = false;
        response->message = "唤醒词不能为空";
        return;
    }

    // 如果阈值为0，使用默认值900
    int32_t threshold = request->threshold;
    if (threshold == 0)
    {
        threshold = 900;
    }

    if (wakeup_handler_)
    {
        wakeup_handler_->SetKeyword(request->keyword, threshold, response->success, response->message);
    }
    else
    {
        response->success = false;
        response->message = "唤醒处理器未初始化";
    }
}

}    // namespace mic_server_virtual
