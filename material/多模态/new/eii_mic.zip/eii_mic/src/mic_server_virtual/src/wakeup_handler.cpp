/**
 * @file wakeup_handler.cpp
 * @brief 唤醒处理模块实现
 */

#include "mic_server_virtual/wakeup_handler.hpp"

#include "mic_server_virtual/serial_handler.hpp"

namespace mic_server_virtual
{

WakeupHandler::WakeupHandler(rclcpp::Node::SharedPtr node, std::shared_ptr<SerialHandler> serial_handler)
    : node_(node), serial_handler_(serial_handler), keyword_("小爱同学"), threshold_(900)
{
    // 创建唤醒事件发布者
    wakeup_pub_ = node_->create_publisher<std_msgs::msg::String>("/mic/wakeup_event", rclcpp::QoS(10));
}

WakeupHandler::~WakeupHandler()
{
}

void WakeupHandler::HandleWakeupMessage(const std::vector<uint8_t> &data)
{
    // 解析唤醒数据并发布唤醒事件
    std::string event_data(data.begin(), data.end());
    auto msg = std_msgs::msg::String();
    msg.data = event_data;
    wakeup_pub_->publish(msg);
}

void WakeupHandler::TriggerManualWakeup(int32_t beam, bool &success, std::string &message)
{
    if (!serial_handler_ || !serial_handler_->IsOpen())
    {
        success = false;
        message = "串口未打开";
        return;
    }

    // 构造JSON命令：{"type":"manual_wakeup","content":{"beam":0}}
    std::string json_cmd = R"({"type":"manual_wakeup","content":{"beam":)" +
                           std::to_string(beam) + R"(}})";

    std::vector<uint8_t> cmd_data(json_cmd.begin(), json_cmd.end());

    // 发送命令并等待响应（使用MANUAL_WAKEUP_TYPE = 0x05）
    SerialMessage response;
    success = serial_handler_->SendCommand(MANUAL_WAKEUP_TYPE, cmd_data, response, 5.0);

    if (success)
    {
        message = "手动唤醒成功";
    }
    else
    {
        message = "手动唤醒失败或超时";
    }
}

void WakeupHandler::SetKeyword(const std::string &keyword, int32_t threshold, bool &success, std::string &message)
{
    if (!serial_handler_ || !serial_handler_->IsOpen())
    {
        success = false;
        message = "串口未打开";
        return;
    }

    // 构造JSON命令：{"type":"wakeup_keywords","content":{"keyword":"xxx","threshold":"900"}}
    std::string json_cmd = R"({"type":"wakeup_keywords","content":{"keyword":")" +
                           keyword + R"(","threshold":")" +
                           std::to_string(threshold) + R"("}})";

    std::vector<uint8_t> cmd_data(json_cmd.begin(), json_cmd.end());

    // 发送命令并等待响应（使用MANUAL_WAKEUP_TYPE = 0x05）
    SerialMessage response;
    success = serial_handler_->SendCommand(MANUAL_WAKEUP_TYPE, cmd_data, response, 5.0);

    if (success)
    {
        keyword_   = keyword;
        threshold_ = threshold;
        message    = "设置唤醒关键词成功";
    }
    else
    {
        message = "设置唤醒关键词失败或超时";
    }
}

}    // namespace mic_server_virtual
